import os
import re
import time
import requests
from flask import Blueprint, request, jsonify
from functools import wraps
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

dvsa_bp = Blueprint('dvsa', __name__)

# DVSA API Configuration
DVSA_CONFIG = {
    'client_id': 'ac13651a-39f7-4b04-82d3-d1a9f92f212d',
    'client_secret': 'LqE8Q~jTvPQWpYPWmNHgq4oz4Bx2yp693nHWxdej',
    'api_key': 'nYV4cOzPl02iQQgWSkLu99cCJbwMiFWdA08aDnTj',
    'scope': 'https://tapi.dvsa.gov.uk/.default',
    'token_url': 'https://login.microsoftonline.com/a455b827-244f-4c97-b5b4-ce5d13b4d00c/oauth2/v2.0/token',
    'api_base_url': 'https://history.mot.api.gov.uk'
}

# Token cache
token_cache = {
    'access_token': None,
    'expires_at': 0
}

def validate_registration(registration):
    """Validate and normalize UK vehicle registration number"""
    if not registration:
        return None, "Registration number is required"
    
    # Remove spaces and convert to uppercase
    reg = re.sub(r'\s+', '', registration.upper())
    
    # UK registration patterns
    patterns = [
        r'^[A-Z]{2}[0-9]{2}[A-Z]{3}$',  # Current format: AB12CDE
        r'^[A-Z][0-9]{1,3}[A-Z]{3}$',   # Prefix format: A123BCD
        r'^[A-Z]{3}[0-9]{1,3}[A-Z]$',   # Suffix format: ABC123D
        r'^[0-9]{1,4}[A-Z]{1,3}$',      # Dateless format: 1234AB
        r'^[A-Z]{1,3}[0-9]{1,4}$'       # Reversed dateless: AB1234
    ]
    
    for pattern in patterns:
        if re.match(pattern, reg):
            return reg, None
    
    return None, "Invalid UK registration number format"

def get_access_token():
    """Get or refresh OAuth2 access token"""
    current_time = time.time()
    
    # Check if we have a valid cached token
    if (token_cache['access_token'] and 
        current_time < token_cache['expires_at'] - 60):  # 60 second buffer
        return token_cache['access_token']
    
    # Request new token
    try:
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        
        data = {
            'grant_type': 'client_credentials',
            'client_id': DVSA_CONFIG['client_id'],
            'client_secret': DVSA_CONFIG['client_secret'],
            'scope': DVSA_CONFIG['scope']
        }
        
        response = requests.post(
            DVSA_CONFIG['token_url'],
            headers=headers,
            data=data,
            timeout=30
        )
        
        if response.status_code == 200:
            token_data = response.json()
            access_token = token_data.get('access_token')
            expires_in = token_data.get('expires_in', 3600)
            
            # Cache the token
            token_cache['access_token'] = access_token
            token_cache['expires_at'] = current_time + expires_in
            
            logger.info("Successfully obtained new access token")
            return access_token
        else:
            logger.error(f"Token request failed: {response.status_code} - {response.text}")
            return None
            
    except Exception as e:
        logger.error(f"Error getting access token: {str(e)}")
        return None

def make_dvsa_request(endpoint, params=None):
    """Make authenticated request to DVSA API"""
    access_token = get_access_token()
    if not access_token:
        return None, "Failed to obtain access token"
    
    headers = {
        'Authorization': f'Bearer {access_token}',
        'X-API-Key': DVSA_CONFIG['api_key'],
        'Accept': 'application/json'
    }
    
    try:
        url = f"{DVSA_CONFIG['api_base_url']}{endpoint}"
        response = requests.get(url, headers=headers, params=params, timeout=30)
        
        if response.status_code == 200:
            return response.json(), None
        elif response.status_code == 404:
            return None, "Vehicle not found"
        elif response.status_code == 403:
            return None, "API access denied - check credentials"
        elif response.status_code == 429:
            return None, "Rate limit exceeded - please try again later"
        else:
            logger.error(f"DVSA API error: {response.status_code} - {response.text}")
            return None, f"API error: {response.status_code}"
            
    except requests.exceptions.Timeout:
        return None, "Request timeout - please try again"
    except requests.exceptions.ConnectionError:
        return None, "Connection error - please check your internet connection"
    except Exception as e:
        logger.error(f"Error making DVSA request: {str(e)}")
        return None, "Internal server error"

@dvsa_bp.route('/vehicle/<registration>', methods=['GET'])
def get_vehicle_data(registration):
    """Get vehicle data by registration number"""
    try:
        # Validate registration number
        normalized_reg, error = validate_registration(registration)
        if error:
            return jsonify({'error': error}), 400
        
        # Make request to DVSA API
        endpoint = f'/v1/trade/vehicles/registration/{normalized_reg}'
        data, error = make_dvsa_request(endpoint)
        
        if error:
            return jsonify({'error': error}), 404 if error == "Vehicle not found" else 500
        
        # Process and return the data
        if data:
            # Add some metadata
            response_data = {
                'success': True,
                'registration': normalized_reg,
                'data': data,
                'timestamp': time.time()
            }
            return jsonify(response_data)
        else:
            return jsonify({'error': 'No data returned from API'}), 500
            
    except Exception as e:
        logger.error(f"Error in get_vehicle_data: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@dvsa_bp.route('/vehicle/vin/<vin>', methods=['GET'])
def get_vehicle_data_by_vin(vin):
    """Get vehicle data by VIN"""
    try:
        if not vin or len(vin) < 10:
            return jsonify({'error': 'Invalid VIN format'}), 400
        
        # Make request to DVSA API
        endpoint = f'/v1/trade/vehicles/vin/{vin}'
        data, error = make_dvsa_request(endpoint)
        
        if error:
            return jsonify({'error': error}), 404 if error == "Vehicle not found" else 500
        
        # Process and return the data
        if data:
            response_data = {
                'success': True,
                'vin': vin,
                'data': data,
                'timestamp': time.time()
            }
            return jsonify(response_data)
        else:
            return jsonify({'error': 'No data returned from API'}), 500
            
    except Exception as e:
        logger.error(f"Error in get_vehicle_data_by_vin: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@dvsa_bp.route('/validate-registration/<registration>', methods=['GET'])
def validate_registration_endpoint(registration):
    """Validate registration number format"""
    try:
        normalized_reg, error = validate_registration(registration)
        
        if error:
            return jsonify({
                'valid': False,
                'error': error,
                'examples': [
                    'AB12CDE (Current format)',
                    'A123BCD (Prefix format)',
                    'ABC123D (Suffix format)'
                ]
            })
        
        return jsonify({
            'valid': True,
            'normalized': normalized_reg,
            'original': registration
        })
        
    except Exception as e:
        logger.error(f"Error in validate_registration_endpoint: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@dvsa_bp.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    try:
        # Test token acquisition
        access_token = get_access_token()
        
        return jsonify({
            'status': 'healthy',
            'api_accessible': access_token is not None,
            'timestamp': time.time()
        })
        
    except Exception as e:
        logger.error(f"Error in health_check: {str(e)}")
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': time.time()
        }), 500



# Write-off detection functionality
def get_writeoff_data(registration):
    """
    Get write-off information for a vehicle
    This function can be extended to integrate with commercial APIs like HPI, UK Vehicle Data, etc.
    """
    try:
        # Demo/Mock data for demonstration purposes
        # In production, this would call a commercial API like HPI or UK Vehicle Data
        
        # Mock write-off database for demonstration
        mock_writeoff_database = {
            'AB12CDE': {
                'isWrittenOff': True,
                'category': 'S',
                'categoryDescription': 'Structural damage - repairable',
                'writeOffDate': '2022-03-15',
                'insuranceCompany': 'Demo Insurance Ltd',
                'estimatedRepairCost': 8500,
                'vehicleValue': 12000,
                'reason': 'Collision damage to front end and chassis',
                'isCurrentCategory': True
            },
            'XY99ZZZ': {
                'isWrittenOff': True,
                'category': 'N',
                'categoryDescription': 'Non-structural damage - repairable',
                'writeOffDate': '2023-07-22',
                'insuranceCompany': 'Example Insurers',
                'estimatedRepairCost': 3200,
                'vehicleValue': 8500,
                'reason': 'Flood damage to interior and electronics',
                'isCurrentCategory': True
            },
            'BC34DEF': {
                'isWrittenOff': True,
                'category': 'B',
                'categoryDescription': 'Break for parts only - body must be crushed',
                'writeOffDate': '2021-11-08',
                'insuranceCompany': 'Safety First Insurance',
                'estimatedRepairCost': 15000,
                'vehicleValue': 6000,
                'reason': 'Severe fire damage',
                'isCurrentCategory': True
            },
            'WR62GWM': {
                'isWrittenOff': True,
                'category': 'N',
                'categoryDescription': 'Non-structural damage - repairable',
                'writeOffDate': '2019-08-14',
                'insuranceCompany': 'Admiral Insurance',
                'estimatedRepairCost': 4200,
                'vehicleValue': 7800,
                'reason': 'Minor collision damage to rear quarter panel and bumper',
                'isCurrentCategory': True
            }
        }
        
        # Check if vehicle has write-off record
        writeoff_info = mock_writeoff_database.get(registration)
        
        if writeoff_info:
            return {
                'hasWriteOff': True,
                'writeOffDetails': writeoff_info,
                'dataSource': 'Demo Database',
                'lastUpdated': time.time()
            }, None
        else:
            return {
                'hasWriteOff': False,
                'writeOffDetails': None,
                'dataSource': 'Demo Database',
                'lastUpdated': time.time()
            }, None
            
    except Exception as e:
        logger.error(f"Error getting write-off data: {str(e)}")
        return None, f"Error retrieving write-off information: {str(e)}"

def integrate_commercial_writeoff_api(registration, api_provider='hpi'):
    """
    Framework for integrating with commercial write-off APIs
    This function shows how to integrate with providers like HPI, UK Vehicle Data, etc.
    """
    try:
        # Example integration patterns for different providers
        
        if api_provider == 'hpi':
            # HPI API integration example
            # This would require HPI API credentials and endpoint
            """
            headers = {
                'Authorization': f'Bearer {HPI_API_KEY}',
                'Content-Type': 'application/json'
            }
            
            response = requests.get(
                f'https://api.hpi.co.uk/v1/vehicle/{registration}/writeoff',
                headers=headers
            )
            
            if response.status_code == 200:
                data = response.json()
                return process_hpi_writeoff_response(data)
            """
            pass
            
        elif api_provider == 'ukvehicledata':
            # UK Vehicle Data API integration example
            """
            headers = {
                'x-api-key': UKV_API_KEY,
                'Content-Type': 'application/json'
            }
            
            response = requests.get(
                f'https://ukvehicledata.co.uk/api/datapackage/{registration}',
                headers=headers
            )
            
            if response.status_code == 200:
                data = response.json()
                return process_ukv_writeoff_response(data)
            """
            pass
            
        # For now, return demo data
        return get_writeoff_data(registration)
        
    except Exception as e:
        logger.error(f"Error in commercial API integration: {str(e)}")
        return None, f"Error accessing commercial write-off database: {str(e)}"

@dvsa_bp.route('/writeoff/<registration>', methods=['GET'])
def get_writeoff_info(registration):
    """Get write-off information for a vehicle"""
    try:
        # Validate registration format
        normalized_reg, validation_error = validate_registration(registration)
        if validation_error:
            return jsonify({'error': validation_error}), 400
        
        # Get write-off data
        writeoff_data, error = get_writeoff_data(normalized_reg)
        
        if error:
            return jsonify({'error': error}), 500
        
        # Add metadata
        response_data = {
            'success': True,
            'registration': normalized_reg,
            'writeOffInfo': writeoff_data,
            'timestamp': time.time(),
            'disclaimer': 'This is a demonstration of write-off detection capabilities. In production, this would integrate with official databases like MIAFTR via commercial providers.'
        }
        
        return jsonify(response_data)
        
    except Exception as e:
        logger.error(f"Error in get_writeoff_info: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@dvsa_bp.route('/vehicle-complete/<registration>', methods=['GET'])
def get_complete_vehicle_data(registration):
    """Get complete vehicle data including MOT history and write-off information"""
    try:
        # Validate registration format
        normalized_reg, validation_error = validate_registration(registration)
        if validation_error:
            return jsonify({'error': validation_error}), 400
        
        # Get DVSA data
        endpoint = f'/v1/trade/vehicles/registration/{normalized_reg}'
        dvsa_data, dvsa_error = make_dvsa_request(endpoint)
        
        # Get write-off data
        writeoff_data, writeoff_error = get_writeoff_data(normalized_reg)
        
        # Combine all data
        complete_data = {
            'success': True,
            'registration': normalized_reg,
            'timestamp': time.time()
        }
        
        # Add DVSA data
        if dvsa_data:
            complete_data['vehicleData'] = dvsa_data
        elif dvsa_error:
            complete_data['vehicleDataError'] = dvsa_error
        
        # Add write-off data
        if writeoff_data:
            complete_data['writeOffInfo'] = writeoff_data
        elif writeoff_error:
            complete_data['writeOffError'] = writeoff_error
        
        return jsonify(complete_data)
        
    except Exception as e:
        logger.error(f"Error in get_complete_vehicle_data: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500


